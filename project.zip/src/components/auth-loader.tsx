
export const AuthLoader = () => {
  return (
    <div className="rh-loader">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  );
};
